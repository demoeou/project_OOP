﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Linq;
using System.Text;
using System.IO;
using System.Text.Json;

namespace ApartmentManagement
{
    public partial class Form1 : Form
    {
        private List<Apartment> apartments = new List<Apartment>();
        private string currentFileName = "apartments.json";

        public Form1()
        {
            InitializeComponent();
            this.FormClosed += Form1_FormClosed;
            LoadDataFromFile(); // Завантажити дані при запуску
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            SaveDataToFile(); // Зберегти дані при закритті
        }

        // === ФАЙЛОВІ ОПЕРАЦІЇ ===

        private void SaveDataToFile()
        {
            try
            {
                var options = new JsonSerializerOptions { WriteIndented = true };
                string json = JsonSerializer.Serialize(apartments, options);
                File.WriteAllText(currentFileName, json);
                MessageBox.Show("Дані збережено у файл: " + currentFileName);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка збереження: {ex.Message}");
            }
        }

        private void LoadDataFromFile()
        {
            try
            {
                if (File.Exists(currentFileName))
                {
                    string json = File.ReadAllText(currentFileName);
                    apartments = JsonSerializer.Deserialize<List<Apartment>>(json);
                    UpdateApartmentList();
                    MessageBox.Show("Дані завантажено з файлу: " + currentFileName);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка завантаження: {ex.Message}");
            }
        }

        private void ExportToTextFile()
        {
            try
            {
                using (StreamWriter writer = new StreamWriter("apartments_export.txt", false, Encoding.UTF8))
                {
                    writer.WriteLine("=== ЕКСПОРТ ДАНИХ ПРО КВАРТИРИ ===");
                    writer.WriteLine($"Дата експорту: {DateTime.Now}");
                    writer.WriteLine(new string('=', 50));

                    foreach (var apt in apartments)
                    {
                        writer.WriteLine(apt.GetApartmentInfo());
                        writer.WriteLine(new string('-', 40));
                    }

                    writer.WriteLine($"Всього квартир: {apartments.Count}");
                }
                MessageBox.Show("Дані експортовано у файл: apartments_export.txt");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка експорту: {ex.Message}");
            }
        }

        private void UpdateApartmentList()
        {
            listApartments.Items.Clear();
            foreach (var apt in apartments)
            {
                listApartments.Items.Add(apt.ToString());
            }
        }

        // === ОБРОБНИКИ ПОДІЙ ДЛЯ НОВИХ КНОПОК ===

        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveDataToFile();
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            LoadDataFromFile();
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            ExportToTextFile();
        }

        // === ОСНОВНІ МЕТОДИ ===

        private void btnAddApartment_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNumber.Text) ||
                string.IsNullOrWhiteSpace(txtArea.Text) ||
                string.IsNullOrWhiteSpace(txtRooms.Text) ||
                string.IsNullOrWhiteSpace(txtElectricity.Text))
            {
                MessageBox.Show("Заповніть всі поля!");
                return;
            }

            if (!int.TryParse(txtNumber.Text, out int number) ||
                !double.TryParse(txtArea.Text, out double area) ||
                !int.TryParse(txtRooms.Text, out int rooms) ||
                !double.TryParse(txtElectricity.Text, out double electricity))
            {
                MessageBox.Show("Введіть коректні числа!");
                return;
            }

            if (number <= 0 || area <= 0 || rooms <= 0 || electricity < 0)
            {
                MessageBox.Show("Значення мають бути більше 0!");
                return;
            }

            try
            {
                Apartment apartment = new Apartment(number, area, rooms, electricity);
                apartments.Add(apartment);

                listApartments.Items.Add(apartment.ToString());

                txtNumber.Clear();
                txtArea.Clear();
                txtRooms.Clear();
                txtElectricity.Clear();

                MessageBox.Show("Квартиру додано!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка: {ex.Message}");
            }
        }

        private void btnShowAll_Click(object sender, EventArgs e)
        {
            if (apartments.Count == 0)
            {
                MessageBox.Show("Немає квартир!");
                return;
            }

            string result = "=== ВСІ КВАРТИРИ ===\n\n";
            foreach (var apt in apartments)
            {
                result += apt.GetApartmentInfo() + "\n\n";
            }
            txtResult.Text = result;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtResult.Clear();
        }

        private void btnDemoLinq_Click(object sender, EventArgs e)
        {
            DemoLinqOperations();
        }

        private void DemoLinqOperations()
        {
            if (!apartments.Any())
            {
                MessageBox.Show("Спочатку додайте квартири!");
                return;
            }

            StringBuilder sb = new StringBuilder();
            sb.AppendLine("=== ОПЕРАЦІЇ LINQ З КОЛЕКЦІЯМИ ===\n");

            var largeApartments = apartments.Where(a => a.Area > 60).ToList();
            sb.AppendLine("1. Фільтрація (квартири > 60 кв.м):");
            foreach (var apt in largeApartments)
            {
                sb.AppendLine($"   - {apt}");
            }
            sb.AppendLine();

            var sortedByRooms = apartments.OrderBy(a => a.Rooms).ThenBy(a => a.Area).ToList();
            sb.AppendLine("2. Сортування (за кімнатами, потім за площею):");
            foreach (var apt in sortedByRooms)
            {
                sb.AppendLine($"   - {apt.Rooms} кім., {apt.Area} кв.м: {apt.Number}");
            }
            sb.AppendLine();

            var groupedByRooms = apartments.GroupBy(a => a.Rooms);
            sb.AppendLine("3. Групування (за кількістю кімнат):");
            foreach (var group in groupedByRooms)
            {
                sb.AppendLine($"   {group.Key} кімнат: {group.Count()} квартир");
                foreach (var apt in group)
                {
                    sb.AppendLine($"     - Кв.{apt.Number} ({apt.Area} кв.м)");
                }
            }
            sb.AppendLine();

            sb.AppendLine("4. Агрегатні функції:");
            sb.AppendLine($"   Загальна площа: {apartments.Sum(a => a.Area):F1} кв.м");
            sb.AppendLine($"   Середня площа: {apartments.Average(a => a.Area):F1} кв.м");
            sb.AppendLine($"   Макс. споживання: {apartments.Max(a => a.ElectricityConsumption)} кВт");
            sb.AppendLine($"   Мін. споживання: {apartments.Min(a => a.ElectricityConsumption)} кВт");
            sb.AppendLine($"   Всього квартир: {apartments.Count}");
            sb.AppendLine();

            var apartmentInfo = apartments.Select(a => new
            {
                Number = a.Number,
                Info = $"{a.Rooms} кім., {a.Area} кв.м, {a.ElectricityConsumption} кВт"
            }).ToList();
            sb.AppendLine("5. Проекція");
            foreach (var info in apartmentInfo)
            {
                sb.AppendLine($"   Кв.{info.Number}: {info.Info}");
            }
            sb.AppendLine();

            sb.AppendLine("6. Топ-3 найбільших квартир:");
            var top3Largest = apartments.OrderByDescending(a => a.Area).Take(3);
            foreach (var apt in top3Largest)
            {
                sb.AppendLine($"   - Кв.{apt.Number}: {apt.Area} кв.м");
            }

            txtResult.Text = sb.ToString();
        }
    }
}