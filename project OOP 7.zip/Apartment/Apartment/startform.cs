﻿using System;
using System.Windows.Forms;

namespace ApartmentManagement
{
    public partial class StartForm : Form
    {
        public StartForm()
        {
            InitializeComponent();
        }

        private void btnOpenMainForm_Click(object sender, EventArgs e)
        {

            Form1 mainForm = new Form1();
            mainForm.Show();

            this.Hide();


            mainForm.FormClosed += (s, args) => this.Close();
        }
    }
}