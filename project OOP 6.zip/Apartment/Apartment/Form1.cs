﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Linq;
using System.Text;

namespace ApartmentManagement
{
    public partial class Form1 : Form
    {
        private List<Apartment> apartments = new List<Apartment>();

        public Form1()
        {
            InitializeComponent();
            AddDemoButton();
            this.FormClosed += Form1_FormClosed;
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            // Можна додати додаткову логіку при закритті форми
        }

        private void AddDemoButton()
        {
            Button btnDemo = new Button();
            btnDemo.Text = "Демо методи";
            btnDemo.Location = new System.Drawing.Point(280, 120);
            btnDemo.Size = new System.Drawing.Size(100, 30);
            btnDemo.BackColor = System.Drawing.SystemColors.ActiveCaption;
            btnDemo.Click += btnDemo_Click;
            this.Controls.Add(btnDemo);
        }

        private void btnAddApartment_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNumber.Text) ||
                string.IsNullOrWhiteSpace(txtArea.Text) ||
                string.IsNullOrWhiteSpace(txtRooms.Text) ||
                string.IsNullOrWhiteSpace(txtElectricity.Text))
            {
                MessageBox.Show("Заповніть всі поля!");
                return;
            }

            if (!int.TryParse(txtNumber.Text, out int number) ||
                !double.TryParse(txtArea.Text, out double area) ||
                !int.TryParse(txtRooms.Text, out int rooms) ||
                !double.TryParse(txtElectricity.Text, out double electricity))
            {
                MessageBox.Show("Введіть коректні числа!");
                return;
            }

            if (number <= 0 || area <= 0 || rooms <= 0 || electricity < 0)
            {
                MessageBox.Show("Значення мають бути більше 0!");
                return;
            }

            try
            {
                Apartment apartment = new Apartment(number, area, rooms, electricity);
                apartments.Add(apartment);

                listApartments.Items.Add(apartment.ToString());

                txtNumber.Clear();
                txtArea.Clear();
                txtRooms.Clear();
                txtElectricity.Clear();

                MessageBox.Show("Квартиру додано!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка: {ex.Message}");
            }
        }

        private void btnShowAll_Click(object sender, EventArgs e)
        {
            if (apartments.Count == 0)
            {
                MessageBox.Show("Немає квартир!");
                return;
            }

            string result = "=== ВСІ КВАРТИРИ ===\n\n";
            foreach (var apt in apartments)
            {
                result += apt.GetApartmentInfo() + "\n\n";
            }
            txtResult.Text = result;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtResult.Clear();
        }

        private void btnDemo_Click(object sender, EventArgs e)
        {
            if (apartments.Count == 0)
            {
                MessageBox.Show("Спочатку додайте квартиру!");
                return;
            }

            Apartment demo = apartments[0];
            string result = "=== ДЕМОНСТРАЦІЯ МЕТОДІВ ===\n\n";

            result += "ПОЧАТКОВИЙ СТАН:\n";
            result += demo.GetApartmentInfo() + "\n\n";

            double testArea = demo.Area;
            result += "1. Передача за значенням:\n";
            result += $"До: testArea = {testArea}\n";
            demo.UpdateArea(testArea);
            result += $"Після: testArea = {testArea}\n";
            result += $"Площа в об'єкті: {demo.Area}\n\n";

            bool h = demo.HasHeating;
            bool w = demo.HasHotWater;
            bool f = demo.HasFurniture;
            result += "2. Передача за посиланням (ref):\n";
            result += $"До: heating={h}, water={w}, furniture={f}\n";
            demo.ImproveComfort(ref h, ref w, ref f);
            result += $"Після: heating={h}, water={w}, furniture={f}\n\n";

            demo.GetComfortStatus(out string comfort);
            result += "3. Передача за посиланням (out):\n";
            result += $"Рівень комфорту: {comfort}\n\n";

            result += "ФІНАЛЬНИЙ СТАН:\n";
            result += demo.GetApartmentInfo();

            txtResult.Text = result;
        }

        private void txtElectricity_TextChanged(object sender, EventArgs e)
        {

        }

 
        private void btnDemoLinq_Click(object sender, EventArgs e)
        {
            DemoLinqOperations();
        }

        private void DemoLinqOperations()
        {
            if (!apartments.Any())
            {
                MessageBox.Show("Спочатку додайте квартири!");
                return;
            }

            StringBuilder sb = new StringBuilder();
            sb.AppendLine("=== ОПЕРАЦІЇ LINQ З КОЛЕКЦІЯМИ ===\n");


            var largeApartments = apartments.Where(a => a.Area > 60).ToList();
            sb.AppendLine("1. Фільтрація (квартири > 60 кв.м):");
            foreach (var apt in largeApartments)
            {
                sb.AppendLine($"   - {apt}");
            }
            sb.AppendLine();


            var sortedByRooms = apartments.OrderBy(a => a.Rooms).ThenBy(a => a.Area).ToList();
            sb.AppendLine("2. Сортування (за кімнатами, потім за площею):");
            foreach (var apt in sortedByRooms)
            {
                sb.AppendLine($"   - {apt.Rooms} кім., {apt.Area} кв.м: {apt.Number}");
            }
            sb.AppendLine();


            var groupedByRooms = apartments.GroupBy(a => a.Rooms);
            sb.AppendLine("3. Групування (за кількістю кімнат):");
            foreach (var group in groupedByRooms)
            {
                sb.AppendLine($"   {group.Key} кімнат: {group.Count()} квартир");
                foreach (var apt in group)
                {
                    sb.AppendLine($"     - Кв.{apt.Number} ({apt.Area} кв.м)");
                }
            }
            sb.AppendLine();


            sb.AppendLine("4. Агрегатні функції:");
            sb.AppendLine($"   Загальна площа: {apartments.Sum(a => a.Area):F1} кв.м");
            sb.AppendLine($"   Середня площа: {apartments.Average(a => a.Area):F1} кв.м");
            sb.AppendLine($"   Макс. споживання: {apartments.Max(a => a.ElectricityConsumption)} кВт");
            sb.AppendLine($"   Мін. споживання: {apartments.Min(a => a.ElectricityConsumption)} кВт");
            sb.AppendLine($"   Всього квартир: {apartments.Count}");
            sb.AppendLine();


            var apartmentInfo = apartments.Select(a => new
            {
                Number = a.Number,
                Info = $"{a.Rooms} кім., {a.Area} кв.м, {a.ElectricityConsumption} кВт"
            }).ToList();
            sb.AppendLine("5. Проекція");
            foreach (var info in apartmentInfo)
            {
                sb.AppendLine($"   Кв.{info.Number}: {info.Info}");
            }
            sb.AppendLine();


            sb.AppendLine("6. Топ-3 найбільших квартир:");
            var top3Largest = apartments.OrderByDescending(a => a.Area).Take(3);
            foreach (var apt in top3Largest)
            {
                sb.AppendLine($"   - Кв.{apt.Number}: {apt.Area} кв.м");
            }

            txtResult.Text = sb.ToString();
        }
    }
}