﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Forms;
using System.Linq;
using System.Text;
using System.IO;
using System.Text.Json;

namespace ApartmentManagement
{
    public partial class Form1 : Form
    {
        private List<Apartment> apartments = new List<Apartment>();
        private string currentFileName = "apartments.json";
        private ApartmentCache apartmentCache = new ApartmentCache();

        public Form1()
        {
            InitializeComponent();
            LoadDataFromFile(); // Синхронне завантаження при старті
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            SaveDataToFile(); // Зберегти дані при закритті
        }

        // === ФАЙЛОВІ ОПЕРАЦІЇ ===

        private void SaveDataToFile()
        {
            try
            {
                var options = new JsonSerializerOptions { WriteIndented = true };
                string json = JsonSerializer.Serialize(apartments, options);

                // Синхронний запис
                File.WriteAllText(currentFileName, json, Encoding.UTF8);

                // Оновлення кешу
                apartmentCache.UpdateCache(apartments);

                MessageBox.Show("Дані збережено у файл: " + currentFileName);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка збереження: {ex.Message}");
            }
        }

        private void LoadDataFromFile()
        {
            try
            {
                // Перевірка кешу перед читанням файлу
                if (apartmentCache.IsValid)
                {
                    apartments = apartmentCache.GetCachedApartments().ToList();
                    UpdateApartmentList();
                    return;
                }

                if (File.Exists(currentFileName))
                {
                    // Синхронне читання
                    string json = File.ReadAllText(currentFileName, Encoding.UTF8);
                    apartments = JsonSerializer.Deserialize<List<Apartment>>(json) ?? new List<Apartment>();

                    apartmentCache.UpdateCache(apartments);
                    UpdateApartmentList();
                    MessageBox.Show("Дані завантажено з файлу: " + currentFileName);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка завантаження: {ex.Message}");
            }
        }

        private void ExportToTextFile()
        {
            try
            {
                var sb = new StringBuilder();
                sb.AppendLine("=== ЕКСПОРТ ДАНИХ ПРО КВАРТИРИ ===");
                sb.AppendLine($"Дата експорту: {DateTime.Now}");
                sb.AppendLine(new string('=', 50));

                var exportData = apartments
                    .Where(apt => apt != null)
                    .Select(apt => apt.GetApartmentInfo());

                foreach (var info in exportData)
                {
                    sb.AppendLine(info);
                    sb.AppendLine(new string('-', 40));
                }

                sb.AppendLine($"Всього квартир: {apartments.Count}");

                // Синхронний запис
                File.WriteAllText("apartments_export.txt", sb.ToString(), Encoding.UTF8);
                MessageBox.Show("Дані експортовано у файл: apartments_export.txt");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка експорту: {ex.Message}");
            }
        }

        // === ОПТИМІЗОВАНІ МЕТОДИ РОБОТИ З ІНТЕРФЕЙСОМ ===

        private void UpdateApartmentList()
        {
            listApartments.BeginUpdate();
            try
            {
                listApartments.Items.Clear();

                var displayApartments = apartments
                    .Where(apt => apt != null)
                    .OrderBy(apt => apt.Number)
                    .Select(apt => apt.ToString());

                listApartments.Items.AddRange(displayApartments.ToArray());
            }
            finally
            {
                listApartments.EndUpdate();
            }
        }

        private void ClearInputFields()
        {
            txtNumber.Clear();
            txtArea.Clear();
            txtRooms.Clear();
            txtElectricity.Clear();
            txtNumber.Focus();
        }

        // === ОБРОБНИКИ ПОДІЙ ===

        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveDataToFile();
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            LoadDataFromFile();
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            ExportToTextFile();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtResult.Clear();
        }

        private void btnShowAll_Click(object sender, EventArgs e)
        {
            if (!apartments.Any())
            {
                MessageBox.Show("Немає квартир!");
                return;
            }

            var sb = new StringBuilder();
            sb.AppendLine("=== ВСІ КВАРТИРИ ===");
            sb.AppendLine();

            var apartmentInfos = apartments
                .Where(apt => apt != null)
                .OrderBy(apt => apt.Number)
                .Select(apt => apt.GetApartmentInfo());

            foreach (var info in apartmentInfos)
            {
                sb.AppendLine(info);
                sb.AppendLine();
            }

            txtResult.Text = sb.ToString();
        }

        private void btnDemoLinq_Click(object sender, EventArgs e)
        {
            DemoLinqOperations();
        }

        private void btnAddApartment_Click(object sender, EventArgs e)
        {
            if (!ValidateInput())
                return;

            try
            {
                var apartment = CreateApartmentFromInput();

                if (apartments.Any(a => a.Number == apartment.Number))
                {
                    MessageBox.Show("Квартира з таким номером вже існує!");
                    return;
                }

                apartments.Add(apartment);
                UpdateApartmentList();
                ClearInputFields();
                MessageBox.Show("Квартиру додано!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка: {ex.Message}");
            }
        }

        private bool ValidateInput()
        {
            if (string.IsNullOrWhiteSpace(txtNumber.Text) ||
                string.IsNullOrWhiteSpace(txtArea.Text) ||
                string.IsNullOrWhiteSpace(txtRooms.Text) ||
                string.IsNullOrWhiteSpace(txtElectricity.Text))
            {
                MessageBox.Show("Заповніть всі поля!");
                return false;
            }

            if (!int.TryParse(txtNumber.Text, out int number) || number <= 0 ||
                !double.TryParse(txtArea.Text, out double area) || area <= 0 ||
                !int.TryParse(txtRooms.Text, out int rooms) || rooms <= 0 ||
                !double.TryParse(txtElectricity.Text, out double electricity) || electricity < 0)
            {
                MessageBox.Show("Введіть коректні додатні числа!");
                return false;
            }

            return true;
        }

        private Apartment CreateApartmentFromInput()
        {
            return new Apartment(
                int.Parse(txtNumber.Text),
                double.Parse(txtArea.Text),
                int.Parse(txtRooms.Text),
                double.Parse(txtElectricity.Text)
            );
        }

        // === LINQ ОПЕРАЦІЇ ===

        private void DemoLinqOperations()
        {
            if (!apartments.Any())
            {
                MessageBox.Show("Спочатку додайте квартири!");
                return;
            }

            StringBuilder sb = new StringBuilder();
            sb.AppendLine("=== ОПЕРАЦІЇ LINQ З КОЛЕКЦІЯМИ ===\n");

            var validApartments = apartments.Where(a => a != null).ToList();

            // 1. Фільтрація
            var largeApartments = validApartments.Where(a => a.Area > 60).ToList();
            sb.AppendLine("1. Фільтрація (квартири > 60 кв.м):");
            foreach (var apt in largeApartments)
            {
                sb.AppendLine($"   - {apt}");
            }
            sb.AppendLine();

            // 2. Сортування
            var sortedByRooms = validApartments.OrderBy(a => a.Rooms).ThenBy(a => a.Area).ToList();
            sb.AppendLine("2. Сортування (за кімнатами, потім за площею):");
            foreach (var apt in sortedByRooms)
            {
                sb.AppendLine($"   - {apt.Rooms} кім., {apt.Area} кв.м: {apt.Number}");
            }
            sb.AppendLine();

            // 3. Групування
            var groupedByRooms = validApartments.GroupBy(a => a.Rooms);
            sb.AppendLine("3. Групування (за кількістю кімнат):");
            foreach (var group in groupedByRooms)
            {
                sb.AppendLine($"   {group.Key} кімнат: {group.Count()} квартир");
                foreach (var apt in group)
                {
                    sb.AppendLine($"     - Кв.{apt.Number} ({apt.Area} кв.м)");
                }
            }
            sb.AppendLine();

            // 4. Агрегатні функції
            sb.AppendLine("4. Агрегатні функції:");
            sb.AppendLine($"   Загальна площа: {validApartments.Sum(a => a.Area):F1} кв.м");
            sb.AppendLine($"   Середня площа: {validApartments.Average(a => a.Area):F1} кв.м");
            sb.AppendLine($"   Макс. споживання: {validApartments.Max(a => a.ElectricityConsumption)} кВт");
            sb.AppendLine($"   Мін. споживання: {validApartments.Min(a => a.ElectricityConsumption)} кВт");
            sb.AppendLine($"   Всього квартир: {validApartments.Count}");
            sb.AppendLine();

            // 5. Проекція
            var apartmentInfo = validApartments.Select(a => new
            {
                Number = a.Number,
                Info = $"{a.Rooms} кім., {a.Area} кв.м, {a.ElectricityConsumption} кВт"
            }).ToList();
            sb.AppendLine("5. Проекція");
            foreach (var info in apartmentInfo)
            {
                sb.AppendLine($"   Кв.{info.Number}: {info.Info}");
            }
            sb.AppendLine();

            // 6. Топ-3
            sb.AppendLine("6. Топ-3 найбільших квартир:");
            var top3Largest = validApartments.OrderByDescending(a => a.Area).Take(3);
            foreach (var apt in top3Largest)
            {
                sb.AppendLine($"   - Кв.{apt.Number}: {apt.Area} кв.м");
            }

            txtResult.Text = sb.ToString();
        }
    }

    // Клас для кешування даних
    public class ApartmentCache
    {
        private List<Apartment> cachedApartments = new List<Apartment>();
        private DateTime lastUpdate = DateTime.MinValue;
        private readonly TimeSpan cacheDuration = TimeSpan.FromMinutes(5);

        public bool IsValid => DateTime.Now - lastUpdate < cacheDuration && cachedApartments.Any();

        public IEnumerable<Apartment> GetCachedApartments()
        {
            return cachedApartments.ToList();
        }

        public void UpdateCache(List<Apartment> apartments)
        {
            cachedApartments = apartments.ToList();
            lastUpdate = DateTime.Now;
        }

        public void InvalidateCache()
        {
            cachedApartments.Clear();
            lastUpdate = DateTime.MinValue;
        }
    }
}