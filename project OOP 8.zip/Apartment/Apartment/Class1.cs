﻿using System;
using System.Collections.Generic;

namespace ApartmentManagement
{
    [Serializable]
    public class Apartment
    {
        private static readonly Random random = new Random();

        // Автоматичні властивості для кращої серіалізації
        public int Number { get; set; }
        public double Area { get; set; }
        public int Rooms { get; set; }
        public double ElectricityConsumption { get; set; }
        public bool HasHeating { get; set; }
        public bool HasHotWater { get; set; }
        public bool HasFurniture { get; set; }

        public string ComfortInfo => GenerateComfortInfo();

        public Apartment() { }

        public Apartment(int number, double area, int rooms, double electricityConsumption)
        {
            // Валідація в конструкторі
            if (number <= 0) throw new ArgumentException("Номер квартири має бути більше 0");
            if (area <= 0) throw new ArgumentException("Площа має бути більше 0");

            Number = number;
            Area = area;
            Rooms = rooms;
            ElectricityConsumption = electricityConsumption;

            // Випадкове призначення комфорту
            HasHeating = random.Next(2) == 1;
            HasHotWater = random.Next(2) == 1;
            HasFurniture = random.Next(2) == 1;
        }

        private string GenerateComfortInfo()
        {
            // Ефективне формування інформації про комфорт
            return $"Опалення: {(HasHeating ? "Є" : "Немає")}, " +
                   $"Гаряча вода: {(HasHotWater ? "Є" : "Немає")}, " +
                   $"Меблі: {(HasFurniture ? "Є" : "Немає")}";
        }

        public string GetApartmentInfo()
        {
            return $"Квартира #{Number}\n" +
                   $"Площа: {Area:F1} кв.м\n" +
                   $"Кімнат: {Rooms}\n" +
                   $"Електрика: {ElectricityConsumption:F1} кВт\n" +
                   $"{ComfortInfo}";
        }

        public override string ToString()
        {
            return $"Кв.{Number} ({Area:F1}кв.м, {Rooms}кім.)";
        }
    }
}