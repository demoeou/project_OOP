﻿using System;
using System.Windows.Forms;

namespace ApartmentManagement
{
    public partial class StartForm : Form
    {
        public StartForm()
        {
            InitializeComponent();
        }

        private void btnOpenMainForm_Click(object sender, EventArgs e)
        {
            // Відкриваємо основну форму
            Form1 mainForm = new Form1();
            mainForm.Show();

            // Ховаємо стартову форму
            this.Hide();

            // Коли основна форма закриється, закриваємо і стартову
            mainForm.FormClosed += (s, args) => this.Close();
        }
    }
}