﻿using System;

namespace ApartmentManagement
{
    public class Apartment
    {
        // Поля класу - два зробимо приватними
        private int number; // приватне поле
        private double area;
        private int rooms;
        private double electricityConsumption; // приватне поле

        // Властивості для доступу до полів
        public int Number
        {
            get { return number; }
            set { number = value; }
        }

        public double Area
        {
            get { return area; }
            set { area = value; }
        }

        public int Rooms
        {
            get { return rooms; }
            set { rooms = value; }
        }

        public double ElectricityConsumption
        {
            get { return electricityConsumption; }
            set { electricityConsumption = value; }
        }

        // Методи для роботи з приватним полем number
        public void SetNumber(int value)
        {
            if (value > 0)
            {
                number = value;
            }
            else
            {
                throw new ArgumentException("Номер квартири має бути більше 0");
            }
        }

        public int GetNumber()
        {
            return number;
        }

        // Методи для роботи з приватним полем electricityConsumption
        public void SetElectricityConsumption(double value)
        {
            if (value >= 0)
            {
                electricityConsumption = value;
            }
            else
            {
                throw new ArgumentException("Споживання електроенергії не може бути від'ємним");
            }
        }

        public double GetElectricityConsumption()
        {
            return electricityConsumption;
        }

        // Конструктор за замовчуванням
        public Apartment()
        {
            number = 0;
            area = 0;
            rooms = 0;
            electricityConsumption = 0;
        }

        // Конструктор з параметрами
        public Apartment(int number, double area, int rooms, double electricityConsumption)
        {
            SetNumber(number);
            this.area = area;
            this.rooms = rooms;
            SetElectricityConsumption(electricityConsumption);
        }

        // Метод для відображення інформації про квартиру
        public string GetApartmentInfo()
        {
            return $"Номер: {number}\nПлоща: {area} кв.м\nКімнат: {rooms}\nСпоживання електроенергії: {electricityConsumption} кВт/год";
        }

        // Метод ToString() для отримання інформації у текстовому вигляді
        public override string ToString()
        {
            return $"Квартира #{number}: {area} кв.м, {rooms} кімнат, споживання: {electricityConsumption} кВт/год";
        }
    }
}