﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace ApartmentManagement
{
    public partial class Form1 : Form
    {
        private List<Apartment> apartments = new List<Apartment>();

        public Form1()
        {
            InitializeComponent();

            // Додаємо обробники подій для перевірки введення
            txtNumber.KeyPress += AllowOnlyNumbers;
            txtRooms.KeyPress += AllowOnlyNumbers;
            txtArea.KeyPress += AllowNumbersAndComma;
            txtElectricity.KeyPress += AllowNumbersAndComma;
        }

        // Дозволяє вводити тільки цифри та Backspace
        private void AllowOnlyNumbers(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        // Дозволяє вводити цифри, кому та Backspace (для дробових чисел)
        private void AllowNumbersAndComma(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != ',')
            {
                e.Handled = true;
            }

            // Дозволяє тільки одну кому
            if (e.KeyChar == ',' && ((TextBox)sender).Text.Contains(","))
            {
                e.Handled = true;
            }
        }

        private void btnAddApartment_Click(object sender, EventArgs e)
        {
            // Перевірка на порожні поля
            if (string.IsNullOrWhiteSpace(txtNumber.Text) ||
                string.IsNullOrWhiteSpace(txtArea.Text) ||
                string.IsNullOrWhiteSpace(txtRooms.Text) ||
                string.IsNullOrWhiteSpace(txtElectricity.Text))
            {
                MessageBox.Show("Будь ласка, заповніть всі поля!", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Перевірка коректності введення за допомогою TryParse
            if (!int.TryParse(txtNumber.Text, out int number) ||
                !double.TryParse(txtArea.Text, out double area) ||
                !int.TryParse(txtRooms.Text, out int rooms) ||
                !double.TryParse(txtElectricity.Text, out double electricity))
            {
                MessageBox.Show("Некоректний формат даних! Використовуйте тільки числа.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Додаткова перевірка на коректність значень
            if (number <= 0 || area <= 0 || rooms <= 0 || electricity < 0)
            {
                MessageBox.Show("Значення мають бути більше 0!", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                // Створення нової квартири з використанням методів доступу
                Apartment apartment = new Apartment();
                apartment.SetNumber(number); // Використання методу для приватного поля
                apartment.Area = area;       // Публічна властивість
                apartment.Rooms = rooms;     // Публічна властивість
                apartment.SetElectricityConsumption(electricity); // Використання методу для приватного поля

                apartments.Add(apartment);

                // Додавання до списку (використовуємо методи доступу для отримання значень)
                listApartments.Items.Add($"Кв.{apartment.GetNumber()} ({apartment.Area} кв.м, {apartment.Rooms} кім.)");

                // Очищення полів введення
                txtNumber.Clear();
                txtArea.Clear();
                txtRooms.Clear();
                txtElectricity.Clear();

                MessageBox.Show("Квартиру додано успішно!", "Успіх", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show($"Помилка: {ex.Message}", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnShowAll_Click(object sender, EventArgs e)
        {
            if (apartments.Count == 0)
            {
                MessageBox.Show("Список квартир порожній!", "Інформація", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string result = "=== ВСІ КВАРТИРИ (використання GetApartmentInfo) ===\n\n";
            for (int i = 0; i < apartments.Count; i++)
            {
                result += $"--- КВАРТИРА {i + 1} ---\n";
                result += apartments[i].GetApartmentInfo();
                result += "\n\n";
            }

            result += "=== ВСІ КВАРТИРИ (використання ToString) ===\n\n";
            for (int i = 0; i < apartments.Count; i++)
            {
                result += $"{i + 1}. {apartments[i].ToString()}\n";
            }

            txtResult.Text = result;
        }

        private void btnShowToString_Click(object sender, EventArgs e)
        {
            if (apartments.Count == 0)
            {
                MessageBox.Show("Список квартир порожній!", "Інформація", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string result = "=== ВСІ КВАРТИРИ (метод ToString()) ===\n\n";
            for (int i = 0; i < apartments.Count; i++)
            {
                result += $"{i + 1}. {apartments[i].ToString()}\n";
            }

            txtResult.Text = result;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtResult.Clear();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void txtElectricity_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnDemoAccessMethods_Click(object sender, EventArgs e)
        {
            if (apartments.Count == 0)
            {
                MessageBox.Show("Спочатку додайте хоча б одну квартиру!", "Інформація", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Демонстрація роботи методів доступу
            Apartment demoApartment = apartments[0];
            string demoInfo = "=== ДЕМОНСТРАЦІЯ МЕТОДІВ ДОСТУПУ ===\n\n";
            demoInfo += $"Отримання номера через GetNumber(): {demoApartment.GetNumber()}\n";
            demoInfo += $"Отримання споживання через GetElectricityConsumption(): {demoApartment.GetElectricityConsumption()}\n";
            demoInfo += $"Отримання площі через публічну властивість: {demoApartment.Area}\n";
            demoInfo += $"Отримання кімнат через публічну властивість: {demoApartment.Rooms}\n";

            txtResult.Text = demoInfo;
        }
    }
}