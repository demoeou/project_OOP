﻿namespace ApartmentManagement
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.txtResult = new System.Windows.Forms.TextBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtNumber = new System.Windows.Forms.TextBox();
            this.txtArea = new System.Windows.Forms.TextBox();
            this.txtRooms = new System.Windows.Forms.TextBox();
            this.txtElectricity = new System.Windows.Forms.TextBox();
            this.btnAddApartment = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.listApartments = new System.Windows.Forms.ListBox();
            this.btnShowAll = new System.Windows.Forms.Button();
            this.btnDemoLinq = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnStatistics = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnLoadTxt = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtResult
            // 
            this.txtResult.BackColor = System.Drawing.Color.Gray;
            this.txtResult.Location = new System.Drawing.Point(12, 200);
            this.txtResult.Multiline = true;
            this.txtResult.Name = "txtResult";
            this.txtResult.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtResult.Size = new System.Drawing.Size(463, 200);
            this.txtResult.TabIndex = 0;
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.Gray;
            this.btnClear.Location = new System.Drawing.Point(379, 410);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(96, 40);
            this.btnClear.TabIndex = 2;
            this.btnClear.Text = "Очистити";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Gray;
            this.label1.Location = new System.Drawing.Point(12, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Номер:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Gray;
            this.label2.Location = new System.Drawing.Point(12, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Площа:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Gray;
            this.label3.Location = new System.Drawing.Point(12, 75);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Кімнат:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Gray;
            this.label4.Location = new System.Drawing.Point(12, 105);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(151, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Споживання електроенергії:";
            // 
            // txtNumber
            // 
            this.txtNumber.BackColor = System.Drawing.Color.Gray;
            this.txtNumber.Location = new System.Drawing.Point(169, 12);
            this.txtNumber.Name = "txtNumber";
            this.txtNumber.Size = new System.Drawing.Size(100, 20);
            this.txtNumber.TabIndex = 7;
            // 
            // txtArea
            // 
            this.txtArea.BackColor = System.Drawing.Color.Gray;
            this.txtArea.Location = new System.Drawing.Point(169, 42);
            this.txtArea.Name = "txtArea";
            this.txtArea.Size = new System.Drawing.Size(100, 20);
            this.txtArea.TabIndex = 8;
            // 
            // txtRooms
            // 
            this.txtRooms.BackColor = System.Drawing.Color.Gray;
            this.txtRooms.Location = new System.Drawing.Point(169, 72);
            this.txtRooms.Name = "txtRooms";
            this.txtRooms.Size = new System.Drawing.Size(100, 20);
            this.txtRooms.TabIndex = 9;
            // 
            // txtElectricity
            // 
            this.txtElectricity.BackColor = System.Drawing.Color.Gray;
            this.txtElectricity.Location = new System.Drawing.Point(169, 98);
            this.txtElectricity.Name = "txtElectricity";
            this.txtElectricity.Size = new System.Drawing.Size(100, 20);
            this.txtElectricity.TabIndex = 10;
            // 
            // btnAddApartment
            // 
            this.btnAddApartment.BackColor = System.Drawing.Color.Gray;
            this.btnAddApartment.Location = new System.Drawing.Point(12, 130);
            this.btnAddApartment.Name = "btnAddApartment";
            this.btnAddApartment.Size = new System.Drawing.Size(257, 30);
            this.btnAddApartment.TabIndex = 11;
            this.btnAddApartment.Text = "Додати квартиру";
            this.btnAddApartment.UseVisualStyleBackColor = false;
            this.btnAddApartment.Click += new System.EventHandler(this.btnAddApartment_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Gray;
            this.label5.Location = new System.Drawing.Point(325, 19);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(135, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Список доданих квартир:";
            // 
            // listApartments
            // 
            this.listApartments.BackColor = System.Drawing.Color.Gray;
            this.listApartments.FormattingEnabled = true;
            this.listApartments.Location = new System.Drawing.Point(275, 35);
            this.listApartments.Name = "listApartments";
            this.listApartments.Size = new System.Drawing.Size(200, 121);
            this.listApartments.TabIndex = 13;
            // 
            // btnShowAll
            // 
            this.btnShowAll.BackColor = System.Drawing.Color.Gray;
            this.btnShowAll.Location = new System.Drawing.Point(12, 410);
            this.btnShowAll.Name = "btnShowAll";
            this.btnShowAll.Size = new System.Drawing.Size(100, 40);
            this.btnShowAll.TabIndex = 14;
            this.btnShowAll.Text = "Показати всі";
            this.btnShowAll.UseVisualStyleBackColor = false;
            this.btnShowAll.Click += new System.EventHandler(this.btnShowAll_Click);
            // 
            // btnDemoLinq
            // 
            this.btnDemoLinq.BackColor = System.Drawing.Color.Gray;
            this.btnDemoLinq.Location = new System.Drawing.Point(118, 410);
            this.btnDemoLinq.Name = "btnDemoLinq";
            this.btnDemoLinq.Size = new System.Drawing.Size(100, 40);
            this.btnDemoLinq.TabIndex = 15;
            this.btnDemoLinq.Text = "LINQ Операції";
            this.btnDemoLinq.UseVisualStyleBackColor = false;
            this.btnDemoLinq.Click += new System.EventHandler(this.btnDemoLinq_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.Gray;
            this.btnSave.Location = new System.Drawing.Point(12, 170);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(80, 25);
            this.btnSave.TabIndex = 16;
            this.btnSave.Text = "Зберегти";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnStatistics
            // 
            this.btnStatistics.BackColor = System.Drawing.Color.Gray;
            this.btnStatistics.Location = new System.Drawing.Point(98, 170);
            this.btnStatistics.Name = "btnStatistics";
            this.btnStatistics.Size = new System.Drawing.Size(85, 25);
            this.btnStatistics.TabIndex = 19;
            this.btnStatistics.Text = "Статистика";
            this.btnStatistics.UseVisualStyleBackColor = false;
            this.btnStatistics.Click += new System.EventHandler(this.btnStatistics_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Gray;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.InitialImage = null;
            this.pictureBox1.Location = new System.Drawing.Point(-151, -521);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(656, 1005);
            this.pictureBox1.TabIndex = 20;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // btnLoadTxt
            // 
            this.btnLoadTxt.BackColor = System.Drawing.Color.Gray;
            this.btnLoadTxt.Location = new System.Drawing.Point(189, 170);
            this.btnLoadTxt.Name = "btnLoadTxt";
            this.btnLoadTxt.Size = new System.Drawing.Size(98, 25);
            this.btnLoadTxt.TabIndex = 21;
            this.btnLoadTxt.Text = "Завантажити TXT";
            this.btnLoadTxt.UseVisualStyleBackColor = false;
            this.btnLoadTxt.Click += new System.EventHandler(this.btnLoadTxt_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(501, 478);
            this.Controls.Add(this.btnLoadTxt);
            this.Controls.Add(this.btnStatistics);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnDemoLinq);
            this.Controls.Add(this.btnShowAll);
            this.Controls.Add(this.listApartments);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnAddApartment);
            this.Controls.Add(this.txtElectricity);
            this.Controls.Add(this.txtRooms);
            this.Controls.Add(this.txtArea);
            this.Controls.Add(this.txtNumber);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.txtResult);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Управління квартирами - LINQ Операції";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtResult;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtNumber;
        private System.Windows.Forms.TextBox txtArea;
        private System.Windows.Forms.TextBox txtRooms;
        private System.Windows.Forms.TextBox txtElectricity;
        private System.Windows.Forms.Button btnAddApartment;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListBox listApartments;
        private System.Windows.Forms.Button btnShowAll;
        private System.Windows.Forms.Button btnDemoLinq;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnStatistics;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnLoadTxt;
    }
}