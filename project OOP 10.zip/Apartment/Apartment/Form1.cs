﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Linq;
using System.Text;
using System.IO;
using System.Text.Json;

namespace ApartmentManagement
{
    public partial class Form1 : Form
    {
        private List<Apartment> apartments = new List<Apartment>();
        private string currentFileName = "apartments.json";

        public Form1()
        {
            InitializeComponent();
        }

        // === ЗАВАНТАЖЕННЯ ТЕКСТОВИХ ФАЙЛІВ ===
        private void btnLoadTxt_Click(object sender, EventArgs e)
        {
            LoadFromTextFile();
        }

        private void LoadFromTextFile()
        {
            try
            {
                using (OpenFileDialog openFileDialog = new OpenFileDialog())
                {
                    openFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
                    openFileDialog.FilterIndex = 1;
                    openFileDialog.RestoreDirectory = true;

                    if (openFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        string filePath = openFileDialog.FileName;
                        string[] lines = File.ReadAllLines(filePath, Encoding.UTF8);

                        int loadedCount = 0;
                        int errorCount = 0;

                        foreach (string line in lines)
                        {
                            if (string.IsNullOrWhiteSpace(line)) continue;

                            try
                            {
                                // Формат: Number,Area,Rooms,Electricity
                                string[] parts = line.Split(',');
                                if (parts.Length == 4)
                                {
                                    int number = int.Parse(parts[0].Trim());
                                    double area = double.Parse(parts[1].Trim());
                                    int rooms = int.Parse(parts[2].Trim());
                                    double electricity = double.Parse(parts[3].Trim());

                                    // Перевірка на дублікат
                                    if (!apartments.Any(a => a.Number == number))
                                    {
                                        var apartment = new Apartment(number, area, rooms, electricity);
                                        apartments.Add(apartment);
                                        loadedCount++;
                                    }
                                    else
                                    {
                                        errorCount++;
                                    }
                                }
                                else
                                {
                                    errorCount++;
                                }
                            }
                            catch
                            {
                                errorCount++;
                            }
                        }

                        UpdateApartmentList();

                        string message = $"Завантажено квартир: {loadedCount}";
                        if (errorCount > 0)
                        {
                            message += $"\nПомилок: {errorCount}";
                        }
                        MessageBox.Show(message, "Результат завантаження");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка завантаження файлу: {ex.Message}", "Помилка");
            }
        }

        // === СТАТИСТИКА ===
        private void btnStatistics_Click(object sender, EventArgs e)
        {
            ShowStatistics();
        }

        private void ShowStatistics()
        {
            if (!apartments.Any())
            {
                MessageBox.Show("Немає квартир для статистики!");
                return;
            }

            var validApartments = apartments.Where(a => a != null).ToList();

            StringBuilder sb = new StringBuilder();
            sb.AppendLine("СТАТИСТИКА КВАРТИР");
            sb.AppendLine();

            // Основна статистика
            sb.AppendLine(" ОСНОВНІ ПОКАЗНИКИ:");
            sb.AppendLine($"   Загальна кількість квартир: {validApartments.Count}");
            sb.AppendLine($"   Середня площа: {validApartments.Average(a => a.Area):F1} кв.м");
            sb.AppendLine($"   Середня кількість кімнат: {validApartments.Average(a => a.Rooms):F1}");
            sb.AppendLine($"   Загальне споживання електроенергії: {validApartments.Sum(a => a.ElectricityConsumption):F1} кВт");
            sb.AppendLine();

            // Екстремальні значення
            sb.AppendLine(" ЕКСТРЕМУМИ:");
            var largestApartment = validApartments.OrderByDescending(a => a.Area).FirstOrDefault();
            var smallestApartment = validApartments.OrderBy(a => a.Area).FirstOrDefault();
            var mostEfficient = validApartments.OrderBy(a => a.ElectricityConsumption).FirstOrDefault();
            var leastEfficient = validApartments.OrderByDescending(a => a.ElectricityConsumption).FirstOrDefault();

            if (largestApartment != null)
                sb.AppendLine($"   Найбільша квартира: Кв.{largestApartment.Number} ({largestApartment.Area} кв.м)");
            if (smallestApartment != null)
                sb.AppendLine($"   Найменша квартира: Кв.{smallestApartment.Number} ({smallestApartment.Area} кв.м)");
            if (mostEfficient != null)
                sb.AppendLine($"   Найенергоефективніша: Кв.{mostEfficient.Number} ({mostEfficient.ElectricityConsumption} кВт)");
            if (leastEfficient != null)
                sb.AppendLine($"   Найенерговитратніша: Кв.{leastEfficient.Number} ({leastEfficient.ElectricityConsumption} кВт)");
            sb.AppendLine();

            // Розподіл за кімнатами
            sb.AppendLine(" РОЗПОДІЛ ЗА КІМНАТАМИ:");
            var roomsDistribution = validApartments.GroupBy(a => a.Rooms)
                                                  .OrderBy(g => g.Key);
            foreach (var group in roomsDistribution)
            {
                sb.AppendLine($"   {group.Key} кімнат: {group.Count()} квартир ({group.Count() * 100.0 / validApartments.Count:F1}%)");
            }

            txtResult.Text = sb.ToString();
        }

        private void SaveDataToFile()
        {
            try
            {
                var options = new JsonSerializerOptions { WriteIndented = true };
                string json = JsonSerializer.Serialize(apartments, options);
                File.WriteAllText(currentFileName, json, Encoding.UTF8);
                MessageBox.Show("Дані збережено у файл: " + currentFileName);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка збереження: {ex.Message}");
            }
        }

        private void LoadDataFromFile()
        {
            try
            {
                if (File.Exists(currentFileName))
                {
                    string json = File.ReadAllText(currentFileName, Encoding.UTF8);
                    apartments = JsonSerializer.Deserialize<List<Apartment>>(json) ?? new List<Apartment>();
                    UpdateApartmentList();
                    MessageBox.Show("Дані завантажено з файлу: " + currentFileName);
                }
                else
                {
                    MessageBox.Show("Файл з даними не знайдено!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка завантаження: {ex.Message}");
            }
        }

        private void UpdateApartmentList()
        {
            listApartments.BeginUpdate();
            try
            {
                listApartments.Items.Clear();
                var displayApartments = apartments
                    .Where(apt => apt != null)
                    .OrderBy(apt => apt.Number)
                    .Select(apt => apt.ToString());
                listApartments.Items.AddRange(displayApartments.ToArray());
            }
            finally
            {
                listApartments.EndUpdate();
            }
        }

        private void ClearInputFields()
        {
            txtNumber.Clear();
            txtArea.Clear();
            txtRooms.Clear();
            txtElectricity.Clear();
            txtNumber.Focus();
        }

        private void btnSave_Click(object sender, EventArgs e) => SaveDataToFile();
        private void btnLoad_Click(object sender, EventArgs e) => LoadDataFromFile();
        private void btnClear_Click(object sender, EventArgs e) => txtResult.Clear();

        private void btnShowAll_Click(object sender, EventArgs e)
        {
            if (!apartments.Any())
            {
                MessageBox.Show("Немає квартир!");
                return;
            }

            var sb = new StringBuilder();
            sb.AppendLine("=== ВСІ КВАРТИРИ ===");
            sb.AppendLine();

            var apartmentInfos = apartments
                .Where(apt => apt != null)
                .OrderBy(apt => apt.Number)
                .Select(apt => apt.GetApartmentInfo());

            foreach (var info in apartmentInfos)
            {
                sb.AppendLine(info);
                sb.AppendLine();
            }

            txtResult.Text = sb.ToString();
        }

        private void btnDemoLinq_Click(object sender, EventArgs e) => DemoLinqOperations();

        private void btnAddApartment_Click(object sender, EventArgs e)
        {
            if (!ValidateInput()) return;

            try
            {
                var apartment = CreateApartmentFromInput();
                if (apartments.Any(a => a.Number == apartment.Number))
                {
                    MessageBox.Show("Квартира з таким номером вже існує!");
                    return;
                }
                apartments.Add(apartment);
                UpdateApartmentList();
                ClearInputFields();
                MessageBox.Show("Квартиру додано!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка: {ex.Message}");
            }
        }

        private bool ValidateInput()
        {
            if (string.IsNullOrWhiteSpace(txtNumber.Text) ||
                string.IsNullOrWhiteSpace(txtArea.Text) ||
                string.IsNullOrWhiteSpace(txtRooms.Text) ||
                string.IsNullOrWhiteSpace(txtElectricity.Text))
            {
                MessageBox.Show("Заповніть всі поля!");
                return false;
            }

            if (!int.TryParse(txtNumber.Text, out int number) || number <= 0 ||
                !double.TryParse(txtArea.Text, out double area) || area <= 0 ||
                !int.TryParse(txtRooms.Text, out int rooms) || rooms <= 0 ||
                !double.TryParse(txtElectricity.Text, out double electricity) || electricity < 0)
            {
                MessageBox.Show("Введіть коректні додатні числа!");
                return false;
            }
            return true;
        }

        private Apartment CreateApartmentFromInput()
        {
            return new Apartment(
                int.Parse(txtNumber.Text),
                double.Parse(txtArea.Text),
                int.Parse(txtRooms.Text),
                double.Parse(txtElectricity.Text)
            );
        }

        private void DemoLinqOperations()
        {
            if (!apartments.Any())
            {
                MessageBox.Show("Спочатку додайте квартири!");
                return;
            }

            StringBuilder sb = new StringBuilder();
            sb.AppendLine("=== ОПЕРАЦІЇ LINQ З КОЛЕКЦІЯМИ ===\n");

            var validApartments = apartments.Where(a => a != null).ToList();

            // 1. Фільтрація
            var largeApartments = validApartments.Where(a => a.Area > 60).ToList();
            sb.AppendLine("1. Фільтрація (квартири > 60 кв.м):");
            foreach (var apt in largeApartments) sb.AppendLine($"   - {apt}");
            sb.AppendLine();

            // 2. Сортування
            var sortedByRooms = validApartments.OrderBy(a => a.Rooms).ThenBy(a => a.Area).ToList();
            sb.AppendLine("2. Сортування (за кімнатами, потім за площею):");
            foreach (var apt in sortedByRooms) sb.AppendLine($"   - {apt.Rooms} кім., {apt.Area} кв.м: {apt.Number}");
            sb.AppendLine();

            // 3. Групування
            var groupedByRooms = validApartments.GroupBy(a => a.Rooms);
            sb.AppendLine("3. Групування (за кількістю кімнат):");
            foreach (var group in groupedByRooms)
            {
                sb.AppendLine($"   {group.Key} кімнат: {group.Count()} квартир");
                foreach (var apt in group) sb.AppendLine($"     - Кв.{apt.Number} ({apt.Area} кв.м)");
            }
            sb.AppendLine();

            // 4. Агрегатні функції
            sb.AppendLine("4. Агрегатні функції:");
            sb.AppendLine($"   Загальна площа: {validApartments.Sum(a => a.Area):F1} кв.м");
            sb.AppendLine($"   Середня площа: {validApartments.Average(a => a.Area):F1} кв.м");
            sb.AppendLine($"   Макс. споживання: {validApartments.Max(a => a.ElectricityConsumption)} кВт");
            sb.AppendLine($"   Мін. споживання: {validApartments.Min(a => a.ElectricityConsumption)} кВт");
            sb.AppendLine($"   Всього квартир: {validApartments.Count}");
            sb.AppendLine();

            // 5. Проекція
            var apartmentInfo = validApartments.Select(a => new
            {
                Number = a.Number,
                Info = $"{a.Rooms} кім., {a.Area} кв.м, {a.ElectricityConsumption} кВт"
            }).ToList();
            sb.AppendLine("5. Проекція");
            foreach (var info in apartmentInfo) sb.AppendLine($"   Кв.{info.Number}: {info.Info}");
            sb.AppendLine();

            // 6. Топ-3
            sb.AppendLine("6. Топ-3 найбільших квартир:");
            var top3Largest = validApartments.OrderByDescending(a => a.Area).Take(3);
            foreach (var apt in top3Largest) sb.AppendLine($"   - Кв.{apt.Number}: {apt.Area} кв.м");

            txtResult.Text = sb.ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}