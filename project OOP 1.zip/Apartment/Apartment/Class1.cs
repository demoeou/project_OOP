﻿using System;

namespace ApartmentManagement
{
    public class Apartment
    {
        // Поля класу
        private int number;
        private double area;
        private int rooms;
        private double electricityConsumption;

        // Властивості для доступу до полів
        public int Number
        {
            get { return number; }
            set { number = value; }
        }

        public double Area
        {
            get { return area; }
            set { area = value; }
        }

        public int Rooms
        {
            get { return rooms; }
            set { rooms = value; }
        }

        public double ElectricityConsumption
        {
            get { return electricityConsumption; }
            set { electricityConsumption = value; }
        }

        // Конструктор за замовчуванням
        public Apartment()
        {
            number = 0;
            area = 0;
            rooms = 0;
            electricityConsumption = 0;
        }

        // Конструктор з параметрами
        public Apartment(int number, double area, int rooms, double electricityConsumption)
        {
            this.number = number;
            this.area = area;
            this.rooms = rooms;
            this.electricityConsumption = electricityConsumption;
        }

        // Метод для відображення інформації про квартиру
        public string GetApartmentInfo()
        {
            return $"Номер: {number}\nПлоща: {area} кв.м\nКімнат: {rooms}\nСпоживання електроенергії: {electricityConsumption} кВт/год";
        }
    }
}