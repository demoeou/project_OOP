﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace ApartmentManagement
{
    public partial class Form1 : Form
    {
        private List<Apartment> apartments = new List<Apartment>();

        public Form1()
        {
            InitializeComponent();
            AddDemoButton();
        }

        private void AddDemoButton()
        {
            Button btnDemo = new Button();
            btnDemo.Text = "Демо методи";
            btnDemo.Location = new System.Drawing.Point(280, 120);
            btnDemo.Size = new System.Drawing.Size(100, 30);
            btnDemo.BackColor = System.Drawing.SystemColors.ActiveCaption;
            btnDemo.Click += btnDemo_Click;
            this.Controls.Add(btnDemo);
        }

        private void btnAddApartment_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNumber.Text) ||
                string.IsNullOrWhiteSpace(txtArea.Text) ||
                string.IsNullOrWhiteSpace(txtRooms.Text) ||
                string.IsNullOrWhiteSpace(txtElectricity.Text))
            {
                MessageBox.Show("Заповніть всі поля!");
                return;
            }

            if (!int.TryParse(txtNumber.Text, out int number) ||
                !double.TryParse(txtArea.Text, out double area) ||
                !int.TryParse(txtRooms.Text, out int rooms) ||
                !double.TryParse(txtElectricity.Text, out double electricity))
            {
                MessageBox.Show("Введіть коректні числа!");
                return;
            }

            if (number <= 0 || area <= 0 || rooms <= 0 || electricity < 0)
            {
                MessageBox.Show("Значення мають бути більше 0!");
                return;
            }

            try
            {
                Apartment apartment = new Apartment(number, area, rooms, electricity);
                apartments.Add(apartment);

                listApartments.Items.Add(apartment.ToString());

                txtNumber.Clear();
                txtArea.Clear();
                txtRooms.Clear();
                txtElectricity.Clear();

                MessageBox.Show("Квартиру додано!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка: {ex.Message}");
            }
        }

        private void btnShowAll_Click(object sender, EventArgs e)
        {
            if (apartments.Count == 0)
            {
                MessageBox.Show("Немає квартир!");
                return;
            }

            string result = "=== ВСІ КВАРТИРИ ===\n\n";
            foreach (var apt in apartments)
            {
                result += apt.GetApartmentInfo() + "\n\n";
            }
            txtResult.Text = result;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtResult.Clear();
        }

        private void btnDemo_Click(object sender, EventArgs e)
        {
            if (apartments.Count == 0)
            {
                MessageBox.Show("Спочатку додайте квартиру!");
                return;
            }

            Apartment demo = apartments[0];
            string result = "=== ДЕМОНСТРАЦІЯ МЕТОДІВ ===\n\n";

            result += "ПОЧАТКОВИЙ СТАН:\n";
            result += demo.GetApartmentInfo() + "\n\n";

            double testArea = demo.Area;
            result += "1. Передача за значенням:\n";
            result += $"До: testArea = {testArea}\n";
            demo.UpdateArea(testArea);
            result += $"Після: testArea = {testArea}\n";
            result += $"Площа в об'єкті: {demo.Area}\n\n";

            bool h = demo.HasHeating;
            bool w = demo.HasHotWater;
            bool f = demo.HasFurniture;
            result += "2. Передача за посиланням (ref):\n";
            result += $"До: heating={h}, water={w}, furniture={f}\n";
            demo.ImproveComfort(ref h, ref w, ref f);
            result += $"Після: heating={h}, water={w}, furniture={f}\n\n";

            demo.GetComfortStatus(out string comfort);
            result += "3. Передача за посиланням (out):\n";
            result += $"Рівень комфорту: {comfort}\n\n";

            result += "ФІНАЛЬНИЙ СТАН:\n";
            result += demo.GetApartmentInfo();

            txtResult.Text = result;
        }

        private void txtElectricity_TextChanged(object sender, EventArgs e)
        {
        }
    }
}