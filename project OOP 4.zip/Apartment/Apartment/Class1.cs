﻿using System;

namespace ApartmentManagement
{
    public class Apartment
    {
        private static Random random = new Random();


        private int number;
        private double area;
        private int rooms;
        private double electricityConsumption;

        public bool HasHeating { get; set; }
        public bool HasHotWater { get; set; }
        public bool HasFurniture { get; set; }

        public string ComfortInfo
        {
            get
            {
                return $"Опалення: {(HasHeating ? "Є" : "Немає")}, " +
                       $"Гаряча вода: {(HasHotWater ? "Є" : "Немає")}, " +
                       $"Меблі: {(HasFurniture ? "Є" : "Немає")}";
            }
        }

        public Apartment()
        {
            number = 1;
            area = 50.0;
            rooms = 2;
            electricityConsumption = 100.0;
            HasHeating = random.Next(2) == 1;
            HasHotWater = random.Next(2) == 1;
            HasFurniture = random.Next(2) == 1;
        }

        public Apartment(int number, int rooms)
        {
            this.number = number;
            this.rooms = rooms;
            area = 60.0;
            electricityConsumption = 120.0;
            HasHeating = random.Next(2) == 1;
            HasHotWater = random.Next(2) == 1;
            HasFurniture = random.Next(2) == 1;
        }

        public Apartment(int number, double area, int rooms, double electricityConsumption)
        {
            this.number = number;
            this.area = area;
            this.rooms = rooms;
            this.electricityConsumption = electricityConsumption;
            HasHeating = random.Next(2) == 1;
            HasHotWater = random.Next(2) == 1;
            HasFurniture = random.Next(2) == 1;
        }

        public int Number
        {
            get { return number; }
            set { number = value; }
        }

        public double Area
        {
            get { return area; }
            set { area = value; }
        }

        public int Rooms
        {
            get { return rooms; }
            set { rooms = value; }
        }

        public double ElectricityConsumption
        {
            get { return electricityConsumption; }
            set { electricityConsumption = value; }
        }

        public void SetNumber(int value)
        {
            if (value > 0)
            {
                number = value;
            }
            else
            {
                throw new ArgumentException("Номер квартири має бути більше 0");
            }
        }

        public int GetNumber()
        {
            return number;
        }

        public void SetElectricityConsumption(double value)
        {
            if (value >= 0)
            {
                electricityConsumption = value;
            }
            else
            {
                throw new ArgumentException("Споживання електроенергії не може бути від'ємним");
            }
        }

        public double GetElectricityConsumption()
        {
            return electricityConsumption;
        }

        public string GetApartmentInfo()
        {
            return $"Квартира #{number}\n" +
                   $"Площа: {area} кв.м\n" +
                   $"Кімнат: {rooms}\n" +
                   $"Електрика: {electricityConsumption} кВт\n" +
                   $"{ComfortInfo}";
        }

        public override string ToString()
        {
            return $"Кв.{number} ({area}кв.м, {rooms}кім.)";
        }


        public void UpdateArea(double newArea)
        {
            newArea = newArea + 5.0; 
            Area = newArea;
        }

        public void ImproveComfort(ref bool heating, ref bool water, ref bool furniture)
        {
            heating = true;
            water = true;
            furniture = true;
        }

        public void GetComfortStatus(out string status)
        {
            int points = 0;
            if (HasHeating) points++;
            if (HasHotWater) points++;
            if (HasFurniture) points++;

            if (points == 3) status = "Високий комфорт";
            else if (points == 2) status = "Середній комфорт";
            else status = "Базовий комфорт";
        }
    }
}