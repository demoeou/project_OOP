﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace ApartmentManagement
{
    public partial class Form1 : Form
    {
        private List<Apartment> apartments = new List<Apartment>();

        public Form1()
        {
            InitializeComponent();

    
            txtNumber.KeyPress += AllowOnlyNumbers;
            txtRooms.KeyPress += AllowOnlyNumbers;
            txtArea.KeyPress += AllowNumbersAndComma;
            txtElectricity.KeyPress += AllowNumbersAndComma;
        }


        private void AllowOnlyNumbers(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }


        private void AllowNumbersAndComma(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != ',')
            {
                e.Handled = true;
            }

  
            if (e.KeyChar == ',' && ((TextBox)sender).Text.Contains(","))
            {
                e.Handled = true;
            }
        }

        private void btnAddApartment_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(txtNumber.Text) ||
                string.IsNullOrWhiteSpace(txtArea.Text) ||
                string.IsNullOrWhiteSpace(txtRooms.Text) ||
                string.IsNullOrWhiteSpace(txtElectricity.Text))
            {
                MessageBox.Show("Будь ласка, заповніть всі поля!", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            if (!int.TryParse(txtNumber.Text, out int number) ||
                !double.TryParse(txtArea.Text, out double area) ||
                !int.TryParse(txtRooms.Text, out int rooms) ||
                !double.TryParse(txtElectricity.Text, out double electricity))
            {
                MessageBox.Show("Некоректний формат даних! Використовуйте тільки числа.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            if (number <= 0 || area <= 0 || rooms <= 0 || electricity < 0)
            {
                MessageBox.Show("Значення мають бути більше 0!", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {

                Apartment apartment = new Apartment(number, area, rooms, electricity);
                apartments.Add(apartment);


                listApartments.Items.Add($"Кв.{apartment.GetNumber()} ({apartment.Area} кв.м, {apartment.Rooms} кім.)");

                txtNumber.Clear();
                txtArea.Clear();
                txtRooms.Clear();
                txtElectricity.Clear();

                MessageBox.Show("Квартиру додано успішно!", "Успіх", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show($"Помилка: {ex.Message}", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnShowAll_Click(object sender, EventArgs e)
        {
            if (apartments.Count == 0)
            {
                MessageBox.Show("Список квартир порожній!", "Інформація", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string result = "=== ВСІ КВАРТИРИ ===\r\n\r\n";
            for (int i = 0; i < apartments.Count; i++)
            {
                result += $"{i + 1}. {apartments[i].ToString()}\r\n";
            }

            txtResult.Text = result;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtResult.Clear();
        }

        private void txtElectricity_TextChanged(object sender, EventArgs e)
        {
  
        }


        private void DemoConstructors()
        {
            string result = "=== ЛАБОРАТОРНА РОБОТА №3 - КОНСТРУКТОРИ ===\r\n\r\n";

 
            Apartment demo = new Apartment();
            result += demo.DemonstrateConstructors();
            result += "\r\n\r\n" + Apartment.ReplaceAssignmentsWithConstructors();

            txtResult.Text = result;
        }


        private void btnShowAll_Click_1(object sender, EventArgs e)
        {
            if (apartments.Count == 0)
            {
                MessageBox.Show("Список квартир порожній!", "Інформація", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string result = "=== ВСІ КВАРТИРИ ===\r\n\r\n";
            for (int i = 0; i < apartments.Count; i++)
            {
                result += $"{i + 1}. {apartments[i].ToString()}\r\n";
            }

           
            result += "\r\n\r\n" + "=== ДЕМОНСТРАЦІЯ КОНСТРУКТОРІВ ===\r\n\r\n";

            
            Apartment apt1 = new Apartment(); 
            Apartment apt2 = new Apartment(999, 2); 
            Apartment apt3 = new Apartment(1000, 85.5, 3, 180.0); 

            result += $"Конструктор без параметрів: {apt1}\r\n";
            result += $"Конструктор з 2 параметрами: {apt2}\r\n";
            result += $"Конструктор з усіма параметрами: {apt3}\r\n";

            txtResult.Text = result;
        }
    }
}