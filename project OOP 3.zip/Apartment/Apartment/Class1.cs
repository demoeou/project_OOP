﻿using System;

namespace ApartmentManagement
{
    public class Apartment
    {
        private int number;
        private double area;
        private int rooms;
        private double electricityConsumption;

        public Apartment()
        {
            number = 1;
            area = 50.0;
            rooms = 2;
            electricityConsumption = 100.0;
        }

        public Apartment(int number, int rooms)
        {
            this.number = number;
            this.rooms = rooms;
            area = 60.0;
            electricityConsumption = 120.0;
        }

        public Apartment(int number, double area, int rooms, double electricityConsumption)
        {
            this.number = number;
            this.area = area;
            this.rooms = rooms;
            this.electricityConsumption = electricityConsumption;
        }

        public int Number
        {
            get { return number; }
            set { number = value; }
        }

        public double Area
        {
            get { return area; }
            set { area = value; }
        }

        public int Rooms
        {
            get { return rooms; }
            set { rooms = value; }
        }

        public double ElectricityConsumption
        {
            get { return electricityConsumption; }
            set { electricityConsumption = value; }
        }

        public void SetNumber(int value)
        {
            if (value > 0)
            {
                number = value;
            }
            else
            {
                throw new ArgumentException("Номер квартири має бути більше 0");
            }
        }

        public int GetNumber()
        {
            return number;
        }

        public void SetElectricityConsumption(double value)
        {
            if (value >= 0)
            {
                electricityConsumption = value;
            }
            else
            {
                throw new ArgumentException("Споживання електроенергії не може бути від'ємним");
            }
        }

        public double GetElectricityConsumption()
        {
            return electricityConsumption;
        }

        public string GetApartmentInfo()
        {
            return $"Номер: {number}\nПлоща: {area} кв.м\nКімнат: {rooms}\nСпоживання електроенергії: {electricityConsumption} кВт/год";
        }

        public override string ToString()
        {
            return $"Квартира #{number}: {area} кв.м, {rooms} кімнат, споживання: {electricityConsumption} кВт/год";
        }

        public string DemonstrateConstructors()
        {
            string result = "=== ДЕМОНСТРАЦІЯ КОНСТРУКТОРІВ ===\r\n\r\n";

            Apartment apartment1 = new Apartment();
            result += $"Конструктор без параметрів: {apartment1}\r\n";

            Apartment apartment2 = new Apartment(101, 3);
            result += $"Конструктор з 2 параметрами: {apartment2}\r\n";

            Apartment apartment3 = new Apartment(202, 75.5, 4, 150.0);
            result += $"Конструктор з усіма параметрами: {apartment3}\r\n";

            return result;
        }

        public static string ReplaceAssignmentsWithConstructors()
        {
            string result = "=== ЗАМІНА ПРИСВОЄНЬ НА КОНСТРУКТОРИ ===\r\n\r\n";

            result += "Замість:\r\n";
            result += "Apartment apt = new Apartment();\r\n";
            result += "apt.Number = 5;\r\n";
            result += "apt.Area = 65.0;\r\n";
            result += "apt.Rooms = 3;\r\n";
            result += "apt.ElectricityConsumption = 110.0;\r\n\r\n";

            result += "Використовуємо:\r\n";
            result += "Apartment apt = new Apartment(5, 65.0, 3, 110.0);\r\n\r\n";

            Apartment oldWay = new Apartment();
            oldWay.Number = 5;
            oldWay.Area = 65.0;
            oldWay.Rooms = 3;
            oldWay.ElectricityConsumption = 110.0;

            Apartment newWay = new Apartment(5, 65.0, 3, 110.0);

            result += $"Результат (старий спосіб): {oldWay}\r\n";
            result += $"Результат (новий спосіб): {newWay}\r\n";
            result += "Результати ідентичні!";

            return result;
        }
    }
}